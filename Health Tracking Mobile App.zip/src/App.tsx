import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { FoodTracker } from './components/FoodTracker';
import { WaterTracker } from './components/WaterTracker';
import { ExerciseTracker } from './components/ExerciseTracker';
import { BowelTracker } from './components/BowelTracker';
import { SymptomsTracker } from './components/SymptomsTracker';
import { Utensils, Droplets, Dumbbell, Heart, Stethoscope } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-background p-4 max-w-md mx-auto">
      <div className="mb-6">
        <h1 className="text-center text-primary mb-2">Health Tracker</h1>
        <p className="text-center text-muted-foreground text-sm">
          Track your daily wellness journey
        </p>
      </div>

      <Tabs defaultValue="food" className="w-full">
        <TabsList className="grid w-full grid-cols-5 mb-6">
          <TabsTrigger value="food" className="p-2">
            <Utensils className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="water" className="p-2">
            <Droplets className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="exercise" className="p-2">
            <Dumbbell className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="bowel" className="p-2">
            <Heart className="h-4 w-4" />
          </TabsTrigger>
          <TabsTrigger value="symptoms" className="p-2">
            <Stethoscope className="h-4 w-4" />
          </TabsTrigger>
        </TabsList>

        <TabsContent value="food">
          <FoodTracker />
        </TabsContent>

        <TabsContent value="water">
          <WaterTracker />
        </TabsContent>

        <TabsContent value="exercise">
          <ExerciseTracker />
        </TabsContent>

        <TabsContent value="bowel">
          <BowelTracker />
        </TabsContent>

        <TabsContent value="symptoms">
          <SymptomsTracker />
        </TabsContent>
      </Tabs>
    </div>
  );
}